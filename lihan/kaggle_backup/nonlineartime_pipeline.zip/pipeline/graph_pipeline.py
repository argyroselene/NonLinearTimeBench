"""The 4-stage temporal-graph pipeline (plan section 4B).

Stages 1-2 call the LLM (structured JSON, constrained to the schemas in
schemas.py). Stages 3-4 are deterministic code -- no LLM involved -- so the
only thing that can vary run to run is what the model extracts in stages 1-2.

Each stage's output is kept in the returned result so stage-wise AWT-F1 can be
computed later against the gold JSON (plan's H3a diagnostic requirement).
"""

from graphlib import TopologicalSorter, CycleError

from pipeline.convergence_verification import verify_convergence_points
from pipeline.graph_repair import repair_edges
from pipeline.prompts import node_extraction_prompt, edge_extraction_prompt
from pipeline.schemas import NODE_EXTRACTION_SCHEMA, EDGE_EXTRACTION_SCHEMA

# Allen relations that imply node_i comes no later than node_j, and are thus
# usable as "i before j" edges for the per-thread topological sort. Relations
# not listed here either state simultaneity (equals) or only make sense
# across threads / already-aligned intervals (the interval-overlap family),
# so they are not used to order a single thread's sentence sequence.
_PRECEDENCE_RELATIONS = {"before", "meets", "starts", "finished-by", "overlaps"}
_INVERSE_PRECEDENCE_RELATIONS = {"after", "met-by", "started-by", "finishes", "overlapped-by"}


def _thread_of(node_id, nodes_by_id):
    return nodes_by_id[node_id]["thread_id"]


def topological_sort_per_thread(nodes, edges):
    """Stage 3: deterministic per-thread ordering via Kahn's algorithm.

    Returns {thread_id: [node_id, ...]} in each thread's inferred chronological
    order. Edges that cross threads, or whose relation isn't a precedence
    relation, are ignored here -- cross-thread alignment is stage 4's job.
    """
    nodes_by_id = {n["id"]: n for n in nodes}
    threads = {}
    for n in nodes:
        threads.setdefault(n["thread_id"], set()).add(n["id"])

    sorters = {tid: TopologicalSorter() for tid in threads}
    for tid, ids in threads.items():
        for node_id in sorted(ids):
            sorters[tid].add(node_id)

    for edge in edges:
        i, j, rel = edge["node_i"], edge["node_j"], edge["allen_relation"]
        if i not in nodes_by_id or j not in nodes_by_id:
            continue
        if _thread_of(i, nodes_by_id) != _thread_of(j, nodes_by_id):
            continue
        tid = _thread_of(i, nodes_by_id)
        if rel in _PRECEDENCE_RELATIONS:
            sorters[tid].add(j, i)
        elif rel in _INVERSE_PRECEDENCE_RELATIONS:
            sorters[tid].add(i, j)

    orders = {}
    for tid, sorter in sorters.items():
        try:
            orders[tid] = list(sorter.static_order())
        except CycleError:
            orders[tid] = sorted(threads[tid])
    return orders


def align_convergence_points(thread_orders, convergence_points):
    """Stage 4: deterministic cross-thread merge via shared convergence points.

    Chains together per-thread orders at their convergence anchors: whenever
    two nodes from different threads are marked as the same moment, the
    threads are merged so nodes before/after the anchor in either thread stay
    on the correct side of it. Convergence pairs that don't reference known
    nodes are ignored.
    """
    position = {}
    for tid, order in thread_orders.items():
        for idx, node_id in enumerate(order):
            position[node_id] = (tid, idx)

    anchors = [
        pair for pair in convergence_points
        if len(pair) == 2 and pair[0] in position and pair[1] in position
    ]

    merged = []
    consumed = set()
    remaining_orders = {tid: list(order) for tid, order in thread_orders.items()}

    for a, b in anchors:
        for node_id in (a, b):
            if node_id in consumed:
                continue
            tid, _ = position[node_id]
            while remaining_orders[tid] and remaining_orders[tid][0] != node_id:
                head = remaining_orders[tid].pop(0)
                if head not in consumed:
                    merged.append(head)
                    consumed.add(head)
            if remaining_orders[tid] and remaining_orders[tid][0] == node_id:
                remaining_orders[tid].pop(0)
            if node_id not in consumed:
                merged.append(node_id)
                consumed.add(node_id)

    for tid in sorted(remaining_orders):
        for node_id in remaining_orders[tid]:
            if node_id not in consumed:
                merged.append(node_id)
                consumed.add(node_id)

    return merged


def run_graph_pipeline(passage, llm_client):
    """Runs all 4 stages and returns every stage's output for diagnostic scoring.

    `passage` is a list of sentence strings (index 0 = sentence 1 = "s1").
    """
    node_result = llm_client.complete(node_extraction_prompt(passage), NODE_EXTRACTION_SCHEMA)
    nodes = node_result["events"]

    edge_result = llm_client.complete(edge_extraction_prompt(passage, nodes), EDGE_EXTRACTION_SCHEMA)
    raw_edges = edge_result["edges"]
    raw_convergence_points = edge_result["candidate_convergence_pairs"]

    edges, repair_log = repair_edges(nodes, raw_edges)

    thread_orders = topological_sort_per_thread(nodes, edges)
    convergence_points, convergence_verification_log = verify_convergence_points(
        nodes, thread_orders, raw_convergence_points
    )
    global_order = align_convergence_points(thread_orders, convergence_points)

    return {
        "events": nodes,
        "edges": edges,
        "raw_edges": raw_edges,
        "repair_log": repair_log,
        "raw_convergence_points": raw_convergence_points,
        "candidate_convergence_pairs": raw_convergence_points,
        "convergence_verification_log": convergence_verification_log,
        "thread_orders": thread_orders,
        "global_order": global_order,
        "convergence_points": convergence_points,
    }
