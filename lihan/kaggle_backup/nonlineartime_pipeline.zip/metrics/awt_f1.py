"""AWT-F1 (Allen-Weighted Temporal Graph F1).

A diagnostic, partial-credit metric for scoring a predicted temporal graph
(from a direct baseline or the graph pipeline) against a gold temporal graph,
covering three things no single existing metric (Exact Match, Kendall's tau,
pairwise accuracy) combines: near-miss-aware relation scoring, thread
attribution, and cross-thread convergence detection.

Expected graph shape (matches the dataset schema in data/stories/*):

    {
        "events": [{"id": "s1", "thread_id": "L"}, ...],
        "edges": [{"node_i": "s1", "node_j": "s2", "allen_relation": "before"}, ...],
        "convergence_points": [["s8", "s9"], ...]
    }

Node IDs are sentence-anchored (see the plan's node-correspondence caveat):
gold and predicted events are matched by `id` directly rather than via
embedding-based alignment, which is an explicit scope limitation of the pilot
dataset, not a general solution to the node-correspondence problem tackled by
CALLMSAE's Hungarian Graph Similarity, the Set-Aligning Framework, or GEST.
"""

from itertools import permutations

from metrics.allen_relations import edge_score


def _edge_map(edges):
    return {(e["node_i"], e["node_j"]): e["allen_relation"] for e in edges}


def relation_score(gold_edges, predicted_edges):
    """Average Allen-distance-weighted score over every gold edge.

    A gold edge with no corresponding predicted edge (same node pair, either
    order) scores 0. Returns 1.0 for an empty gold edge set (vacuously correct).
    """
    if not gold_edges:
        return 1.0
    predicted = _edge_map(predicted_edges)
    total = 0.0
    for e in gold_edges:
        key = (e["node_i"], e["node_j"])
        reverse_key = (e["node_j"], e["node_i"])
        if key in predicted:
            total += edge_score(e["allen_relation"], predicted[key])
        elif reverse_key in predicted:
            total += edge_score(e["allen_relation"], predicted[reverse_key])
        else:
            total += 0.0
    return total / len(gold_edges)


def _best_thread_label_mapping(gold_events, predicted_events):
    """Best one-to-one correspondence from predicted thread labels to gold thread
    labels, maximizing co-occurrence over matched node ids.

    Thread labels are free text -- an LLM has no way to reproduce gold's exact
    label string ("L") even when its clustering of events into threads is
    perfectly correct, so thread attribution must be scored on the induced
    partition, not literal string equality. This brute-forces the assignment
    (thread counts are always small in this dataset); if a run somehow yields
    a very large label vocabulary (e.g. a broken prediction with a near-unique
    label per event) the candidate pool on the larger side is capped by
    co-occurrence strength to keep the permutation search bounded.
    """
    predicted_by_id = {e["id"]: e for e in predicted_events}
    pairs = []
    for gold_event in gold_events:
        predicted_event = predicted_by_id.get(gold_event["id"])
        if predicted_event is None:
            continue
        g, p = gold_event.get("thread_id"), predicted_event.get("thread_id")
        if g is not None and p is not None:
            pairs.append((g, p))

    gold_labels = sorted({g for g, _ in pairs})
    pred_labels = sorted({p for _, p in pairs})
    if not gold_labels or not pred_labels:
        return {}

    contingency = {}
    for g, p in pairs:
        contingency[(g, p)] = contingency.get((g, p), 0) + 1

    small, large = (gold_labels, pred_labels) if len(gold_labels) <= len(pred_labels) else (pred_labels, gold_labels)
    small_is_gold = small is gold_labels

    cap = max(len(small) + 4, 10)
    if len(large) > cap:
        overlap_of = lambda label: sum(
            count for (g, p), count in contingency.items()
            if (p if small_is_gold else g) == label
        )
        large = sorted(large, key=overlap_of, reverse=True)[:cap]

    best_score, best_perm = -1, None
    for perm in permutations(large, len(small)):
        score = 0
        for s_label, l_label in zip(small, perm):
            key = (s_label, l_label) if small_is_gold else (l_label, s_label)
            score += contingency.get(key, 0)
        if score > best_score:
            best_score, best_perm = score, perm

    mapping = {}
    for s_label, l_label in zip(small, best_perm):
        gold_label, predicted_label = (s_label, l_label) if small_is_gold else (l_label, s_label)
        mapping[predicted_label] = gold_label
    return mapping


def thread_attribution_accuracy(gold_events, predicted_events):
    """Fraction of gold events whose predicted thread, under the best label
    correspondence to gold's thread vocabulary, matches, by node id.

    A gold event with no matching predicted event id counts as incorrect.
    Returns 1.0 if there are no gold events.
    """
    if not gold_events:
        return 1.0
    predicted_by_id = {e["id"]: e for e in predicted_events}
    mapping = _best_thread_label_mapping(gold_events, predicted_events)
    correct = 0
    for gold_event in gold_events:
        predicted_event = predicted_by_id.get(gold_event["id"])
        if predicted_event is None:
            continue
        predicted_label = predicted_event.get("thread_id")
        if mapping.get(predicted_label) == gold_event.get("thread_id"):
            correct += 1
    return correct / len(gold_events)


def _normalize_pairs(pairs):
    return {frozenset(pair) for pair in pairs}


def convergence_f1(gold_convergence_points, predicted_convergence_points):
    """Precision/recall/F1 over unordered convergence-point pairs.

    Returns (precision, recall, f1). If gold has no convergence points, f1 is
    1.0 when predicted also has none, else 0.0 (a hallucinated convergence is
    a real error, so this case is not vacuously correct).
    """
    gold_set = _normalize_pairs(gold_convergence_points)
    predicted_set = _normalize_pairs(predicted_convergence_points)

    if not gold_set and not predicted_set:
        return 1.0, 1.0, 1.0
    if not gold_set or not predicted_set:
        return 0.0, 0.0, 0.0

    true_positives = len(gold_set & predicted_set)
    precision = true_positives / len(predicted_set)
    recall = true_positives / len(gold_set)
    if precision + recall == 0:
        return precision, recall, 0.0
    f1 = 2 * precision * recall / (precision + recall)
    return precision, recall, f1


def harmonic_mean(scores):
    """Harmonic mean of a list of non-negative scores; 0.0 if any score is 0."""
    if not scores:
        return 0.0
    if any(s <= 0 for s in scores):
        return 0.0
    n = len(scores)
    return n / sum(1.0 / s for s in scores)


def awt_f1(gold, predicted):
    """Compute AWT-F1 and its diagnostic sub-scores for one gold/predicted graph pair.

    Returns a dict: relation_score, thread_attribution_accuracy,
    convergence_precision, convergence_recall, convergence_f1, awt_f1.
    """
    rel_score = relation_score(gold.get("edges", []), predicted.get("edges", []))
    thread_score = thread_attribution_accuracy(
        gold.get("events", []), predicted.get("events", [])
    )
    conv_precision, conv_recall, conv_f1 = convergence_f1(
        gold.get("convergence_points", []), predicted.get("convergence_points", [])
    )
    overall = harmonic_mean([rel_score, thread_score, conv_f1])
    return {
        "relation_score": rel_score,
        "thread_attribution_accuracy": thread_score,
        "convergence_precision": conv_precision,
        "convergence_recall": conv_recall,
        "convergence_f1": conv_f1,
        "awt_f1": overall,
    }


def memorization_gap(awt_f1_original, awt_f1_counterfactual):
    """Delta-AWT-F1 = AWT-F1(original) - AWT-F1(counterfactual), for the overall score
    and every sub-score, given two awt_f1() result dicts."""
    return {
        key: awt_f1_original[key] - awt_f1_counterfactual[key]
        for key in awt_f1_original
    }
